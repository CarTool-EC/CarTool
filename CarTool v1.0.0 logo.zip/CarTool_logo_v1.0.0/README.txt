INSTRUCTIONS TO CREATE A CARTOOL SHORTCUT

A Microsoft Windows icon file with the CarTool logo that can be used to create a CarTool themed shortcut for Archi�. To use this:
1. Copy the CarTool.ico file to a location on your hard disk.
2. Locate your Archi� installation folder and make a shortcut for the Archi executable file (this can be named Archi.exe, Archi32.exe or Archi64.exe, depending on your installation).
3. Edit the shortcut�s properties and select to "Change Icon�".
4. Browse to and select the CarTool.ico file.
